describe service('AlteryxService') do
  it { should be_running }
end
