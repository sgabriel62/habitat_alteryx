alteryx_server_r_package 'Alteryx Predictive Tools' do
  action :uninstall
end

alteryx_server_package 'Alteryx Server' do
  action :uninstall
end
